﻿using CodeFirst_2.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Linq;

void PrintAll(List<Product> products)
{
    foreach (var product in products)
    {
        var SummDiscount = product.Price - (product.Price * (decimal)product.Discount);
        Console.WriteLine("--------------------------------");
        Console.WriteLine("id товара : " + product.PruductId);
        Console.WriteLine("Название товара : "+product.Title);
        Console.WriteLine("Категория: "+product.Category.CategoryTitle);
        Console.WriteLine("Описание: "+product.Discription);
        Console.WriteLine("Фото: "+product.PhotoPath);
        Console.WriteLine("Количество: "+product.Count);
        Console.WriteLine("Цена: "+ Math.Round(product.Price, 2));
        Console.WriteLine("Скидка: "+ product.Discount*100);
        Console.WriteLine("Цена со скидкой: "+Math.Round(SummDiscount,2));
    }
    
}
void PrintAllCategory(List<Category> categories)
{
    
    foreach (var category in categories)
    {
        Console.WriteLine(category.CategoryId+"."+category.CategoryTitle);
    }

}
int end = 1;
List<Product> Products;
bool result;
List<Category> categories;
while(end != 0)
{
    Console.WriteLine("--------------------------------");
    Console.WriteLine("0. Выход");
    Console.WriteLine("1. Вывод всех товаров");
    Console.WriteLine("2. Вывод топа товаров по цене");
    Console.WriteLine("3. Поиск по названию товара");
    Console.WriteLine("4. Вывод товара определённой категории");
    Console.WriteLine("5. Добавить товар");
    Console.WriteLine("6. Удалить товар");
    int answer = int.Parse(Console.ReadLine());

    using (var context = new Strore_DB_Context())
    {
        switch (answer)
        {
            case 0:
                end = 0;
                break;
            case 1:
                Console.WriteLine("Все товары");
                Products = context.Products.Include(p=>p.Category).ToList();
                PrintAll(Products);
                break;
            case 2:
                Console.Write("Введите число товаров для вывода: ");
                int countToPrint = int.Parse(Console.ReadLine());
                Console.WriteLine($"Выведено товаров {countToPrint}:");
                Products = context.Products.Include(p => p.Category).OrderByDescending(p=>p.Price).Take(countToPrint).ToList();
                PrintAll(Products);
                break;
            case 3:
                Console.Write("Поисковой запрос: ");
                var search = Console.ReadLine();
                if(search != "")
                {
                    Products = context.Products.Include(p => p.Category).Where(p => p.Title.Contains(search)).ToList();
                    if (Products.Count!=0)
                    {
                        PrintAll(Products);
                    }
                    else
                    {
                        Console.WriteLine("Нет товаров с таким названием.");
                    }
                }
                else
                {
                    Console.WriteLine("Не допустимое значение - \"Пустая строка\"");
                }
                break;
            case 4:
                Console.WriteLine("Выберите категорию: ");
                Console.WriteLine("--------------------------------");
                categories = context.Categories.ToList();
                PrintAllCategory(categories);
                Console.Write("Категория: ");
                int categoryAnswer = 0;
                result = int.TryParse(Console.ReadLine(), out categoryAnswer);
                if (result)
                {
                    Console.WriteLine("--------------------------------");
                    if (categoryAnswer <= categories.Count && categoryAnswer >= 1)
                    {
                        Products = context.Products.Include(p => p.Category).Where(p => p.Category.CategoryId == categoryAnswer).ToList();
                        if (Products.Count != 0)
                        {
                            PrintAll(Products);
                        }
                        else
                        {
                            Console.WriteLine("Нет товаров с такой категорией.");
                        }

                    }
                    else
                    {
                        Console.WriteLine("Такой категории не существует.");
                    }

                }
                else
                {
                    Console.WriteLine("Только цифры");
                }

                break;
            case 5:
                Console.WriteLine("Выберите категорию: ");
                Console.WriteLine("--------------------------------");
                categories = context.Categories.ToList();
                PrintAllCategory(categories);
                Console.Write("Категория: ");
                int categoryAnswerAdd;

                result = int.TryParse(Console.ReadLine(), out categoryAnswerAdd);
                Console.WriteLine("--------------------------------");
                if(result)
                {
                    if (categoryAnswerAdd <= categories.Count && categoryAnswerAdd >= 1)
                    {
                        var p = new Product();
                        Console.Write("Введите название продукта:");
                        p.Title = Console.ReadLine();
                        Console.Write("Введите путь до фотографии:");
                        p.PhotoPath = Console.ReadLine();
                        Console.Write("Введите описание:");
                        p.Discription = Console.ReadLine();
                        decimal Price;
                        Console.Write("Введите цену товара:");
                        result = decimal.TryParse(Console.ReadLine(), out Price);
                        if(result)
                        {
                            p.Price = Price;
                        }
                        else
                        {
                            Console.WriteLine("Только цифры");
                        }
                        double Discount;
                        Console.Write("Введите скидку на товар от 0 до 100:");
                        result = double.TryParse(Console.ReadLine(), out Discount);
                        if (result)
                        {
                            p.Discount = Discount/100;
                        }
                        else
                        {
                            Console.WriteLine("Только цифры");
                        }
                        int Count;
                        Console.Write("Введите кол-во товаров:");
                        result = int.TryParse(Console.ReadLine(), out Count);
                        if (result)
                        {
                            p.Count = Count;
                        }
                        else
                        {
                            Console.WriteLine("Только цифры");
                        }
                        p.CategoryId = categoryAnswerAdd;



                        List<ValidationResult> results = new List<ValidationResult>();
                        var validationContext = new ValidationContext(p);

                        bool isValid = Validator.TryValidateObject(p, validationContext, results, true);

                        if (!isValid)
                        {
                            foreach (var res in results)
                            {
                                Console.WriteLine(res.ErrorMessage);
                            }
                        }
                        else
                        {
                            context.Products.Add(p);
                            try
                            {
                                context.SaveChanges();
                                Console.WriteLine("Данные добавлены в базу данных:)");
                            }
                            catch
                            {
                                Console.WriteLine("Ошибка, сохранение не произведено");
                                context.Products.Remove(p);
                            }
                        }

                    }
                    else
                    {
                        Console.WriteLine("Такой категории не существует.");
                    }
                }
                else
                {
                    Console.WriteLine("Только цифры");
                }
                break;
            case 6:
                Products = context.Products.Include(p => p.Category).ToList();
                PrintAll(Products);
                Console.WriteLine("Введите индекс товара для его удаления");
                int delIndex;
                result = int.TryParse(Console.ReadLine(), out delIndex);
                if(result)
                {
                    var delElement = Products.FirstOrDefault(p=>p.PruductId==delIndex);
                    context.Products.Remove(delElement);
                    try
                    {
                        context.SaveChanges();
                        Console.WriteLine("Данные добавлены в базу данных:)");
                    }
                    catch
                    {
                        Console.WriteLine("Ошибка, удаление не произведено");
                    }

                }
                else
                {
                    Console.WriteLine("Ошибка, ввод только цифр");
                }
                break;
        }

        
        
    }
}

