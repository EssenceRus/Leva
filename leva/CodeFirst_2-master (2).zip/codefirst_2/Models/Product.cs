﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirst_2.Models
{
    public class Product
    {
        [Key]
        public int PruductId { get; set; }

        [StringLength(100)]
        [MinLength(1)]
        public string Title { get; set; }

        [StringLength(500)]
        [MinLength(1)]
        public string? PhotoPath { get; set; }

        [StringLength(700)]
        [MinLength(1)]
        public string? Discription { get; set; }

        public int Count { get; set; }

        [Column(TypeName = "money")]
        public decimal Price { get; set; }

        [Range(0, 1)]
        public double Discount { get; set; }

        
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
    }
}
