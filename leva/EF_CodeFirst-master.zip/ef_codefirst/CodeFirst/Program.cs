﻿using CodeFirst.Models;
using Microsoft.EntityFrameworkCore;

Seeder.InitialSeed();

var context = new BlogContext();

//foreach (Post post in context.Posts)
//{
//    Console.WriteLine($"=={post.Name}==");
//    Console.WriteLine(post.Text);
//    Console.WriteLine(post.PostTime);
//}

//foreach (Post post in context.Posts.Include(p => p.Blog))
//{
//    Console.WriteLine($"{post.Blog.Name} - {post.Name}");
//    Console.WriteLine(post.Text);
//    Console.WriteLine(post.PostTime);
//}

//var post1 = context.Posts.First();
//context.Entry(post1).Reference(p => p.Blog).Load();
//Console.WriteLine($"{post1.Blog.Name} - {post1.Name}");
//Console.WriteLine(post1.Text);
//Console.WriteLine(post1.PostTime);


//Запрос 1.
foreach (Post post in context.Posts.Include(p => p.Blog).OrderBy(p => p.PostTime))
{
    Console.WriteLine($"{post.Blog.Name} - {post.Name}");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.PostTime);
}
Console.WriteLine("----------------------");
//Запрос 2.
foreach(Post post in context.Posts.Include(p => p.Blog).Where(p=>p.Blog.Name == "Лайфхаки от гусько"))
{
    Console.WriteLine($"{post.Blog.Name} - {post.Name}");
    Console.WriteLine(post.Text);
    Console.WriteLine(post.PostTime);
}
Console.WriteLine("----------------------");
//Запрос 3.
foreach (Blog blog in context.Blogs.Where(b=>b.Posts.Any()))
{
    Console.WriteLine($"{blog.Name}");

}
Console.WriteLine("----------------------");
//Запрос 4.
foreach (Blog blog in context.Blogs.Include(b=>b.Posts))
{ 
    if(blog.Posts.Any(b=>b.PostTime.Year!=DateTime.Now.Year))
    {
        Console.WriteLine($"{blog.Name}");
    }

}
Console.WriteLine("----------------------");
//Запрос 5.
foreach (Blog blog in context.Blogs.Include(b => b.Posts))
{
    
        Console.WriteLine($"{blog.Name}");
        Console.WriteLine($"{blog.Posts.Count}");
    

}
Console.WriteLine("----------------------");
//Запрос 6.
foreach (Post post in context.Posts.Where(p=>p.PostTime.Year == DateTime.Now.Year))
{
    Console.WriteLine($"{post.Name}");
    Console.WriteLine($"{post.Text}");
    Console.WriteLine($"{post.PostTime}");
    
}
Console.WriteLine("----------------------");
//Запрос 7.
var Posts = context.Posts.Include(p => p.Blog).GroupBy(b => b.Blog);
foreach(var post in Posts)
{
    Console.WriteLine($"{post.Key.Name}");
    foreach(var post2 in post)
    {
        Console.WriteLine($"{post2.Name}");
        Console.WriteLine($"{post2.Text}");
        Console.WriteLine($"{post2.PostTime}");
    }

}
