﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SamokatApp.Converters
{
    public class HasErrorsToEnabledMultiConverter :IMultiValueConverter
    {
        public object Convert (object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            // все значения заданы
            if (values.Any(obj => obj is null))
            {
                return false;
            }
            // во всех значениях нет ошибок
            return values.Cast<bool>().All(hasError => !hasError);
        }

        public object[] ConvertBack (object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
