﻿using System;
using System.Collections.Generic;

namespace SamokatApp.Models;

public partial class Samokat
{
    public int SamokatId { get; set; }

    public string SamokatName { get; set; } = null!;

    public int ProductType { get; set; }

    public int Manufacturer { get; set; }

    public decimal Price { get; set; }

    public string? Photo { get; set; } = null!;

    public int MaxLoad { get; set; }

    public int PowerReserve { get; set; }

    public int MaxSpeed { get; set; }

    public int MaxWatt { get; set; }

    public virtual Manufactur ManufacturerNavigation { get; set; } = null!;

    public virtual ProductType ProductTypeNavigation { get; set; } = null!;
}
