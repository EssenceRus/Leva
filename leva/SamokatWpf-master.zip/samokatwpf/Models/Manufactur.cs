﻿using System;
using System.Collections.Generic;

namespace SamokatApp.Models;

public partial class Manufactur
{
    public int ManufacturId { get; set; }

    public string ManufacturName { get; set; } = null!;

    public virtual ICollection<Samokat> Samokats { get; set; } = new List<Samokat>();
}
