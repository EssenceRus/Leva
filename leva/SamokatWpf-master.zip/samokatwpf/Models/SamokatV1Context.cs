﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace SamokatApp.Models;

public partial class SamokatV1Context : DbContext
{
    public SamokatV1Context()
    {
    }

    public SamokatV1Context(DbContextOptions<SamokatV1Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Manufactur> Manufacturs { get; set; }

    public virtual DbSet<ProductType> ProductTypes { get; set; }

    public virtual DbSet<Samokat> Samokats { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=PC310-09;Database=SamokatV2;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Manufactur>(entity =>
        {
            entity.HasKey(e => e.ManufacturId).HasName("PK_Manufactur");

            entity.Property(e => e.ManufacturName).HasMaxLength(100);
        });

        modelBuilder.Entity<ProductType>(entity =>
        {
            entity.Property(e => e.ProductTypeName).HasMaxLength(250);
        });

        modelBuilder.Entity<Samokat>(entity =>
        {
            entity.Property(e => e.Photo).HasMaxLength(100);
            entity.Property(e => e.Price).HasColumnType("money");
            entity.Property(e => e.SamokatName).HasMaxLength(250);

            entity.HasOne(d => d.ManufacturerNavigation).WithMany(p => p.Samokats)
                .HasForeignKey(d => d.Manufacturer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Samokats_Manufacturs");

            entity.HasOne(d => d.ProductTypeNavigation).WithMany(p => p.Samokats)
                .HasForeignKey(d => d.ProductType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Samokats_ProductTypes");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
