﻿using System;
using System.Collections.Generic;

namespace SamokatApp.Models;

public partial class ProductType
{
    public int ProductTypeId { get; set; }

    public string ProductTypeName { get; set; } = null!;

    public virtual ICollection<Samokat> Samokats { get; set; } = new List<Samokat>();
}
