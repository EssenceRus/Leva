﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SamokatApp.Migrations
{
    /// <inheritdoc />
    public partial class PhotoNull : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Manufacturs",
                columns: table => new
                {
                    ManufacturId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ManufacturName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Manufactur", x => x.ManufacturId);
                });

            migrationBuilder.CreateTable(
                name: "ProductTypes",
                columns: table => new
                {
                    ProductTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductTypeName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductTypes", x => x.ProductTypeId);
                });

            migrationBuilder.CreateTable(
                name: "Samokats",
                columns: table => new
                {
                    SamokatId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SamokatName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    ProductType = table.Column<int>(type: "int", nullable: false),
                    Manufacturer = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "money", nullable: false),
                    Photo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    MaxLoad = table.Column<int>(type: "int", nullable: false),
                    PowerReserve = table.Column<int>(type: "int", nullable: false),
                    MaxSpeed = table.Column<int>(type: "int", nullable: false),
                    MaxWatt = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Samokats", x => x.SamokatId);
                    table.ForeignKey(
                        name: "FK_Samokats_Manufacturs",
                        column: x => x.Manufacturer,
                        principalTable: "Manufacturs",
                        principalColumn: "ManufacturId");
                    table.ForeignKey(
                        name: "FK_Samokats_ProductTypes",
                        column: x => x.ProductType,
                        principalTable: "ProductTypes",
                        principalColumn: "ProductTypeId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Samokats_Manufacturer",
                table: "Samokats",
                column: "Manufacturer");

            migrationBuilder.CreateIndex(
                name: "IX_Samokats_ProductType",
                table: "Samokats",
                column: "ProductType");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Samokats");

            migrationBuilder.DropTable(
                name: "Manufacturs");

            migrationBuilder.DropTable(
                name: "ProductTypes");
        }
    }
}
