﻿using SamokatApp.Command;
using SamokatApp.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SamokatApp.ViewModels
{
    public class MainWindowViewModel : BaseViewModel
    {
        private void CloseProgram ()
        {
            Environment.Exit(0);
        }

        public RelayCommand CloseCommand { get; set; }

        public MainWindowViewModel ()
        {
            NavigateProductsPage();
            CloseCommand = new RelayCommand(_ => CloseProgram());

        }

        private Page currentPage = null!;

        public Page CurrentPage
        {
            get => currentPage;
            set => setAndNotify(ref currentPage, value);

        }
       
        public void NavigateProductsPage ()
        {
            CurrentPage = new ProductsListPage(this);
        }
        public void NavigateUpdateProductsPage (int productId)
        {
            CurrentPage = new UpdateProductPage(this, productId);
            
        }

    }
}

