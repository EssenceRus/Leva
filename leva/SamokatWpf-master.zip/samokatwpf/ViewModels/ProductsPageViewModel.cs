﻿using Microsoft.EntityFrameworkCore;
using SamokatApp.Command;
using SamokatApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace SamokatApp.ViewModels
{
    public class ProductsPageViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private readonly MainWindowViewModel mainViewModel;
        public ListCollectionView Products { get; set; }
        public List<ProductType> ProductTypes { get; set; }
        public List<Manufactur> Manufacturers { get; set; }

        public RelayCommand AddProductCommand { get; set; }
        public RelayCommand UpdateProductCommand { get; set; }

        public RelayCommand DeleteProductCommand { get; set; }
        public ProductsPageViewModel (MainWindowViewModel mainViewModel)
        {
            this.mainViewModel = mainViewModel;
            AddProductCommand = new RelayCommand(_ => navigateUpdateProduct(0));
            UpdateProductCommand = new RelayCommand(_ => navigateUpdateProduct(SelectedSamokat?.SamokatId ?? 0));
            DeleteProductCommand = new RelayCommand(_ => DelSamokat());

            using (SamokatV1Context context = new( ))
            {

                Products = new ListCollectionView(context.Samokats.Include(p => p.ManufacturerNavigation).Include(p=>p.ProductTypeNavigation).ToList( ));
                Manufacturers = context.Manufacturs.ToList();
                Manufacturers.Insert(0, new Manufactur { ManufacturId = 0, ManufacturName = "Все производители" });
                ProductTypes = context.ProductTypes.ToList();
                ProductTypes.Insert(0, new ProductType { ProductTypeId = 0, ProductTypeName = "Все типы" });
                selectedManufactur = Manufacturers[0];
                selectedType = ProductTypes[0];
        
            }
        }



        private Samokat? selectedSamokat;

        public event PropertyChangedEventHandler? PropertyChanged;
        public void notifyPropertyChanged (string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }

        public Samokat? SelectedSamokat
        {
            get => selectedSamokat;

            set
            {
                setAndNotify(ref selectedSamokat, value);
                notifyPropertyChanged(nameof(CanEditProduct));
            }
        }

        public bool CanEditProduct => selectedSamokat is not null;

        private string searchString = string.Empty;

        public string SearchString
        {
            get => searchString;
           
            set
            {
                searchString = value;
                // в Filter задается функция от элемента, которая возвращает true
                // если элемент должен остаться в выборке
                Products.Filter = p => filterPredicate((Samokat) p);
            }
        }
        private Manufactur selectedManufactur;

        public Manufactur SelectedManufactur
        {
            get
            {
                return selectedManufactur;
            }

            set
            {
                selectedManufactur = value;
                Products.Filter = p => filterPredicate((Samokat) p);
            }
        }


        private ProductType selectedType;

        public ProductType SelectedType
        {
            get
            {
                return selectedType;
            }

            set
            {
                selectedType = value;
                Products.Filter = p => filterPredicate((Samokat) p);
            }
        }
        private bool filterPredicate (Samokat product)
        {
            return product.SamokatName.Contains(searchString, StringComparison.OrdinalIgnoreCase) &&  // поиск
                (product.Manufacturer == selectedManufactur.ManufacturId || selectedManufactur.ManufacturId == 0) &&
                (product.ProductType == selectedType.ProductTypeId || selectedType.ProductTypeId == 0); // фильтрация
        }
        private void navigateUpdateProduct (int productId)
        {
            mainViewModel.NavigateUpdateProductsPage(productId);
        }
        private void DelSamokat()
        {
            using(var context = new SamokatV1Context())
            {
                context.Remove(SelectedSamokat);
                try
                {

                    context.SaveChanges();
                    Products.Remove(SelectedSamokat);
                } catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
