﻿using SamokatApp.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamokatApp.ViewModels
{
    public class ProductViewModel :BaseViewModel, IDataErrorInfo
    {
        private decimal price;

        public string this[string columnName]
        {
            get
            {
                if (columnName == "Name" && string.IsNullOrWhiteSpace(Name))
                {
                    return "Название товара не может быть пустым!";
                }
                if (columnName == "Name" && Name.Length >= 50)
                {
                    return "Название товара не может содержать более 50 знаков!";
                }
                if (columnName == "Price" && Price < 0)
                {
                    return "Стоимость не может быть отрицательной!";
                }
                if(columnName == "MaxLoad" && MaxLoad <0)
                {
                    return "Грузоподъёмность не может быть отрицательной!";
                }
                if (columnName == "MaxSpeed" && MaxSpeed < 0)
                {
                    return "Скорость не может быть отрицательной!";
                }
                if (columnName == "MaxSpeed" && MaxSpeed > 100)
                {
                    return "Скорость не может быть больше 100!";
                }
                if (columnName == "MaxWatt" && MaxWatt <0)
                {
                    return "Показатель Watt не может быть меньше 0";
                }
                if (columnName == "PowerReserve" && PowerReserve < 0)
                {
                    return "Запас хода не может быть меньше 0";
                }

                return null!;
            }
        }
        public string Error => null!;

        public ProductViewModel () { }

        public ProductViewModel (Samokat product)
        {
            Id = product.SamokatId;
            Name = product.SamokatName;
            Price = product.Price;
            Manufacturer = product.ManufacturerNavigation;
            ProductType = product.ProductTypeNavigation;
            Price = product.Price;
            Photo = product.Photo;
            MaxLoad = product.MaxLoad;
            MaxSpeed = product.MaxSpeed;
            MaxWatt = product.MaxWatt;
            PowerReserve = product.PowerReserve;
        }

        public Samokat ToProduct () => new Samokat
        {
            SamokatId = Id,
            SamokatName = Name,
            Price = Price,
            Photo = Photo,
            MaxLoad = MaxLoad,
            MaxSpeed = MaxSpeed,
            MaxWatt = MaxWatt,
            Manufacturer = Manufacturer!.ManufacturId,
            ProductType = ProductType!.ProductTypeId,
            PowerReserve = PowerReserve

        };

        public int Id { get; set; }
        public string Name { get; set; } = null!;

        public Manufactur? Manufacturer { get; set; }

        public ProductType? ProductType { get; set; }

        public decimal Price { get => price; set => setAndNotify(ref price, value); }
        public string? Photo { get; set; }

        public int MaxLoad { get; set; }
        public int PowerReserve { get; set; }

        public int MaxSpeed { get; set; }
        public int MaxWatt { get; set; }
    }
}
