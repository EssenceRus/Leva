﻿using Microsoft.EntityFrameworkCore;
using SamokatApp.Command;
using SamokatApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamokatApp.ViewModels
{
    public class UpdateProductPageViewModel : BaseViewModel
    {
        private readonly MainWindowViewModel mainWindowViewModel;
        public ProductViewModel Product { get; set; }
        public List<Manufactur> Manufacturers { get; set; }
        public List<ProductType> Types { get; set; }

        public RelayCommand SaveCommand { get; set; }

        public RelayCommand GoBack { get; set; }
        public UpdateProductPageViewModel (MainWindowViewModel mainWindowViewModel, int productId)
        {
            this.mainWindowViewModel = mainWindowViewModel;

            SaveCommand = new RelayCommand(_ => saveChanges());
            GoBack = new RelayCommand(_ => navigateProductsList());

            using (SamokatV1Context context = new())
            {
                var found = context.Samokats
                    .Include(p => p.ManufacturerNavigation)
                    .Include(p => p.ProductTypeNavigation)
                    .FirstOrDefault(p => p.SamokatId == productId);
                Manufacturers = context.Manufacturs.ToList();
                Types = context.ProductTypes.ToList();

                if (found is null)
                {
                    Product = new ProductViewModel();
                    Product.Manufacturer = Manufacturers.FirstOrDefault();
                    Product.ProductType = Types.FirstOrDefault();
                } 
                else
                {
                    Product = new ProductViewModel(found);
                }
            }
        }
        private void navigateProductsList ()
        {
            mainWindowViewModel.NavigateProductsPage();
        }
        private void saveChanges ()
        {
            Samokat product = Product.ToProduct();
            using ( SamokatV1Context context = new SamokatV1Context())
            {
                if (product.SamokatId == 0)
                {
                    context.Samokats.Add(product);
                } else
                {
                    context.Samokats.Update(product);
                }
                context.SaveChanges();
            }
            navigateProductsList();
        }
    }
}
