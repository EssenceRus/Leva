﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf_validation_demo
{
    public class Connection
    {
        public static ValidationUserContext Database { get; set; }
    }
}
