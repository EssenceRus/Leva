﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_validation_demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Connection.Database = new ValidationUserContext();
        }

        private void GoToSimpleValidationWindow(object sender, RoutedEventArgs e)
        {
            var window = new EventHandlerValidationWindow();
            window.ShowDialog();
        }

        private void GoToValidationRuleWindow(object sender, RoutedEventArgs e)
        {
            var window = new ValidationRuleWindow();
            window.ShowDialog();
        }

        private void GoToIDataErrorWindow(object sender, RoutedEventArgs e)
        {
            var window = new IDataErrorWindow();
            window.ShowDialog();
        }

        private void GoToEFValidationWindow(object sender, RoutedEventArgs e)
        {
            var win = new EFValidationWindow();
            win.ShowDialog();
        }
    }
}
