﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace wpf_validation_demo;

public partial class User : IDataErrorInfo
{
    public string this[string columnName]
    {
        get
        {
            if (columnName == "Name")
            {
                if(Name !=null)
                {
                    if (Name.Trim() == "")
                    {
                        return "Имя не может быть пустым!";
                    }
                }
                
            }
            if (columnName == "Username")
            {
                if(Username != null)
                {
                    if (Username.Trim().Length < 3)
                    {
                        return "Имя пользователя должно содержать хотя бы 3 символа!";
                    }
                    if (Username.Trim().Any(ch => !char.IsLetter(ch)))
                    {
                        return "Имя пользователя должно содержать только буквы!";
                    }
                }
                
            }
            if(columnName == "Age")
            {
                if(Age != null)
                {
                    if (Age < 0 || Age > 100)
                    {
                        return "Возраст не может быть меньше 0 или больше 100!";
                    }
                }
                
            }
            return "";
        }
    }
    public int UserId { get; set; }
    [MinLength(3, ErrorMessage = "Имя пользователя должно содержать хотя бы 3 символа!")]
    [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Имя пользователя должно содержать только буквы!")]
    [Required(ErrorMessage = "Username является обязательным")]
    public string? Username { get; set; }

    [Required(ErrorMessage = "Name является обязательным")]
    public string? Name { get; set; }

    [Range(1, 100, ErrorMessage = "Возраст не может быть меньше 0 или больше 100!")]
    [Required(ErrorMessage = "Age должен содержать только цифры")]
    public int? Age { get; set; }

    
    public string Error
    {
        get { throw new NotImplementedException(); }
    }
}
