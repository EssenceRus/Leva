﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_validation_demo
{
    /// <summary>
    /// Логика взаимодействия для EFValidationWindow.xaml
    /// </summary>
    public partial class EFValidationWindow : Window
    {
        private int errorCount = 0;
        public User newUser { get; set; }
        public EFValidationWindow()
        {
            InitializeComponent();

            DataContext = newUser = new User();
        }
        private void TextBox_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
            {
                errorCount++;

                var errorToolTip = new ToolTip();
                errorToolTip.Content = e.Error.ErrorContent;
                (sender as TextBox).ToolTip = errorToolTip;
            }
            else if (e.Action == ValidationErrorEventAction.Removed)
            {
                errorCount--;
            }

            AddUserButton.IsEnabled = errorCount == 0;
        }
        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            var ctx = new ValidationContext(newUser);
            List<System.ComponentModel.DataAnnotations.ValidationResult> errors = new();
            bool isValid = Validator.TryValidateObject(newUser, ctx, errors, true);

            if (isValid)
            {
                if (Connection.Database.Users.FirstOrDefault(u => u.Username == UsernameTextBox.Text.Trim()) != null)
                {
                    MessageBox.Show("Пользователь с таким именем уже существует!");
                    return;
                }
                Connection.Database.Users.Add(newUser);
                try
                {
                    Connection.Database.SaveChanges();
                }
                catch (Exception)
                {

                    throw;
                }
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                foreach (var error in errors)
                {
                    sb.Append(error.ErrorMessage + "\n");

                    
                }
                MessageBox.Show(sb.ToString());
            }
            
        }

        
    }
}
