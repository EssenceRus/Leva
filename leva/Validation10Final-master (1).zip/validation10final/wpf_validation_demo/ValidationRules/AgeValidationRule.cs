﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace wpf_validation_demo.ValidationRules
{
    class AgeValidationRule : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
           int age;

           if(!int.TryParse((string)value, out age))
           {
                return new System.Windows.Controls.ValidationResult(false, "Значение должно быть числом");
           }
           else if (age < 0 || age > 100)
           {
                return new System.Windows.Controls.ValidationResult(false, "Значение должно быть от 0 до 100"); 
           }
           return new System.Windows.Controls.ValidationResult(true, "Всё хорошо");


        }
    }
}
