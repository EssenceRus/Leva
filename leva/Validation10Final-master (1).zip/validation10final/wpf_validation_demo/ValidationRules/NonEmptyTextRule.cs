﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Documents;

namespace wpf_validation_demo.ValidationRules
{
    class NonEmptyTextRule : ValidationRule
    {
        public override System.Windows.Controls.ValidationResult Validate(object value, CultureInfo cultureInfo)
      {
            string text = value as string;
            if(!string.IsNullOrWhiteSpace(text))
            {
                return new System.Windows.Controls.ValidationResult(true, "Всё хорошо");
            }
            return new System.Windows.Controls.ValidationResult(false, "Значение не может быть пустым или состоять из пробелов");

        }
    }
}
