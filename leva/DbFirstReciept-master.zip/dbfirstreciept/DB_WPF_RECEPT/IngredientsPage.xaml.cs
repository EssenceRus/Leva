﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DB_WPF_RECEPT
{
    /// <summary>
    /// Логика взаимодействия для IngredientsPage.xaml
    /// </summary>
    public partial class IngredientsPage : Page
    {
        public IngredientsPage()
        {
            InitializeComponent();
            using (var context = new ReceiptsWpfContext())
            {
                

                

                IngredientsItemsControl.ItemsSource = context
               .Ingridients
               .Include(r => r.ReceiptIngridients)
               .ThenInclude(ri => ri.ReceiptNavigation)
               .ToList();





            }
        }

        private void search_text_change(object sender, TextChangedEventArgs e)
        {
            using (var context = new ReceiptsWpfContext())
            {
                IngredientsItemsControl.ItemsSource = context
                .Ingridients
                .Include(i => i.ReceiptIngridients)
                .ThenInclude(ri => ri.ReceiptNavigation)
                .Where(i => i.Name.Contains(SearchTextBox.Text))
                .ToList();
            }
        }
    }
}
