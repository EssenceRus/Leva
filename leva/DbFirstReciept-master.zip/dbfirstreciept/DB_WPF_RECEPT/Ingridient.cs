﻿using System;
using System.Collections.Generic;

namespace DB_WPF_RECEPT;

public partial class Ingridient
{
    public int IngridientId { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<ReceiptIngridient> ReceiptIngridients { get; } = new List<ReceiptIngridient>();
}
