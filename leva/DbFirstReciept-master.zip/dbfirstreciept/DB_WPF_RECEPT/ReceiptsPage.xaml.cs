﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DB_WPF_RECEPT
{
    /// <summary>
    /// Логика взаимодействия для ReceiptsPage.xaml
    /// </summary>
    public partial class ReceiptsPage : Page
    {
        public ReceiptsPage()
        {
            InitializeComponent();
            using (var context = new ReceiptsWpfContext())
            {
                receiptsItemsControl.ItemsSource = context
                .Receipts
                .Include(r => r.ReceiptIngridients)
                .ThenInclude(ri => ri.IngridientNavigation)
                .ToList();
            }
        }

        private void search_text_change(object sender, TextChangedEventArgs e)
        {
            using (var context = new ReceiptsWpfContext())
            {
                receiptsItemsControl.ItemsSource = context
                .Receipts
                .Include(r => r.ReceiptIngridients)
                .ThenInclude(ri => ri.IngridientNavigation)
                .Where(r=>r.Name.Contains(SearchTextBox.Text))
                .ToList();
            }
        }

        private void search_text_change_ing(object sender, TextChangedEventArgs e)
        {
            using (var context = new ReceiptsWpfContext())
            {
                receiptsItemsControl.ItemsSource = context
                .Receipts
                .Include(r => r.ReceiptIngridients)
                .ThenInclude(ri => ri.IngridientNavigation)
                .Where(r =>r.ReceiptIngridients.Any(ri=>ri.IngridientNavigation.Name.Contains(SearchTextBox_Ingr.Text)))
                .ToList();

                

                
            }
        }
    }
}
