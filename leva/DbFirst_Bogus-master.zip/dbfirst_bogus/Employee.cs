﻿using System;
using System.Collections.Generic;

namespace DbFirst;

public partial class Employee
{
    public int EmployeId { get; set; }

    public string Name { get; set; } = null!;

    public string Surname { get; set; } = null!;

    public string Patronymic { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public DateTime Birthday { get; set; }

    public string Adrees { get; set; } = null!;

    public string PasportNumber { get; set; } = null!;

    public string Email { get; set; } = null!;

    public int JobId { get; set; }

    public virtual Job Job { get; set; } = null!;
}
