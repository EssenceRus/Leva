﻿using Bogus;
using DbFirst;
using DbFirst.Models;
using System.Net.WebSockets;

//Задание 1.
//int i = 1;


//var students = new Faker<Student>("ru")
//    .RuleFor(s => s.id, f => i++)
//    .RuleFor(s => s.Name, f => f.Person.FirstName)
//    .RuleFor(s => s.Surname, f => f.Person.LastName)
//    .RuleFor(s => s.PhoneNumber, f => f.Phone.PhoneNumber("+7(###)-###-####"))
//    .RuleFor(s => s.Birthday, f => f.Date.PastOffset(20, DateTime.Now.AddYears(-18)).Date).Generate(10000);

//foreach (var st in students)
//{
//    Console.WriteLine($"id - {st.id}");
//    Console.WriteLine($"Имя - {st.Name}");
//    Console.WriteLine($"Фамилия - {st.Surname}");
//    Console.WriteLine($"Номер телефона - {st.PhoneNumber}");
//    Console.WriteLine($"День рождения - {st.Birthday}");

//}
List<Job> jobs = new List<Job>(); 
var context = new EmployeesDbContext();
jobs = context.Jobs.ToList();

var Emplo = new Faker<Employee>("ru")
    .RuleFor(e => e.Name, f => f.Person.FirstName)
    .RuleFor(e => e.Surname, f => f.Person.LastName)
    .RuleFor(e => e.Adrees, f => f.Address.FullAddress())
    .RuleFor(e => e.PhoneNumber, f => f.Phone.PhoneNumber("+7(###)-###-####"))
    .RuleFor(e => e.Email, f => f.Person.Email)
    .RuleFor(e => e.Birthday, f => f.Date.PastOffset(20, DateTime.Now.AddYears(-18)).Date)
    .RuleFor(e => e.Job, f => f.Random.ListItem(jobs))
    .RuleFor(e => e.Patronymic, f => f.Person.FirstName)
    .RuleFor(e => e.PasportNumber, f => f.Phone.PhoneNumber("## ## ######")).Generate(100).ToList();

context.Employees.AddRange(Emplo);


try
{
    context.SaveChanges();
    Console.WriteLine("Всё круто");
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}
    
    

